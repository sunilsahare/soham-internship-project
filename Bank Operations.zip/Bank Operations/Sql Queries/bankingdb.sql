-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: bankingdb
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `ano` int NOT NULL,
  `aname` varchar(55) DEFAULT NULL,
  `atype` varchar(12) DEFAULT 'saving',
  `balance` float DEFAULT NULL,
  `opendate` date DEFAULT NULL,
  KEY `ano` (`ano`),
  CONSTRAINT `accounts_ibfk_1` FOREIGN KEY (`ano`) REFERENCES `users` (`userid`) ON DELETE CASCADE,
  CONSTRAINT `accounts_chk_1` CHECK ((`balance` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (20311,'Idea','saving',25000,'2020-04-05'),(20312,'Vodafone','saving',45000,'2020-04-05'),(20313,'Reliance Jio','saving',75599,'2020-04-05'),(20314,'BSNL','saving',15144,'2020-04-05'),(20315,'Bharti Airtel','saving',55000,'2020-04-05'),(20316,'MSEB','saving',127200,'2020-04-05'),(20310,'Shantanu Belankar','saving',45400,'2020-04-05'),(20320,'Avi Randale','saving',12000,'2020-04-05'),(203018,'Shubham Sonar','saving',15000,'2020-04-05');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `removeAcc` AFTER DELETE ON `accounts` FOR EACH ROW begin
         insert into closedaccounts
  set ano=old.ano,
 aname=old.aname,
         atype=old.atype,
         balance=old.balance,
         opendate=old.opendate;
     end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `acctransactions`
--

DROP TABLE IF EXISTS `acctransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acctransactions` (
  `transno` int NOT NULL AUTO_INCREMENT,
  `ano` int DEFAULT NULL,
  `transdt` date DEFAULT NULL,
  `transtype` varchar(20) DEFAULT 'deposit',
  `amount` float DEFAULT NULL,
  PRIMARY KEY (`transno`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acctransactions`
--

LOCK TABLES `acctransactions` WRITE;
/*!40000 ALTER TABLE `acctransactions` DISABLE KEYS */;
INSERT INTO `acctransactions` VALUES (33,20310,'2020-04-05','transfer',1500),(34,20309,'2020-04-05','credits',1500),(35,20309,'2020-04-05','deposit',2000),(36,20309,'2020-04-05','withdraw',100),(37,20309,'2020-04-05','transfer',1900),(38,20310,'2020-04-05','credits',1900),(39,20310,'2020-04-05','withdraw',5000),(40,20309,'2020-04-05','electric bill',500),(41,20316,'2020-04-05','credits',500),(42,20309,'2020-04-05','recharge',599),(43,20313,'2020-04-05','credits',599);
/*!40000 ALTER TABLE `acctransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `closedaccounts`
--

DROP TABLE IF EXISTS `closedaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `closedaccounts` (
  `ano` int NOT NULL DEFAULT '0',
  `username` varchar(45) DEFAULT NULL,
  `aname` varchar(55) DEFAULT NULL,
  `atype` varchar(12) DEFAULT 'saving',
  `balance` float DEFAULT NULL,
  `opendate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `closedaccounts`
--

LOCK TABLES `closedaccounts` WRITE;
/*!40000 ALTER TABLE `closedaccounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `closedaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userdetails` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `userid` int DEFAULT NULL,
  `name` varchar(65) DEFAULT NULL,
  `dob` varchar(10) NOT NULL,
  `mobile` varchar(10) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `regdate` date DEFAULT NULL,
  `secque` varchar(255) DEFAULT NULL,
  `ans` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `userid` (`userid`),
  CONSTRAINT `userdetails_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userdetails`
--

LOCK TABLES `userdetails` WRITE;
/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
INSERT INTO `userdetails` VALUES (7,20310,'Shantanu Belankar','1997-07-17','9846257931','shan12@gmail.com','Tiosa','2020-04-05','What is your first mobile number?','9545171927'),(8,20320,'Avi Randale','1996-07-12','9846257931','avi@gmail.com','Amravati','2020-04-05','What is your first mobile number?','9545171927'),(10,203018,'Shubham Sonar','1994-08-12','9846257931','shubham12@gmail.com','Amravati','2020-04-05','What is your first mobile number?','9545171927');
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `userid` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  `usertype` varchar(10) DEFAULT 'customer',
  `loginstatus` varchar(10) DEFAULT 'active',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (20303,'Branch Manager','manager123','manager','active'),(20304,'Cashier','cashier123','cashier','active'),(20310,'Shantanu Belankar','shan123','customer','active'),(20311,'Idea','idea123','customer','active'),(20312,'Vodafone','vodafone123','customer','active'),(20313,'Reliance Jio','jio123','customer','active'),(20314,'BSNL','bsnl123','customer','active'),(20315,'Bharti Airtel','airtel123','customer','active'),(20316,'MSEB','mseb123','customer','active'),(20320,'Avi Randale','avi@123','customer','active'),(203018,'Shubham Sonar','shubham123','customer','active');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `userview`
--

DROP TABLE IF EXISTS `userview`;
/*!50001 DROP VIEW IF EXISTS `userview`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `userview` AS SELECT 
 1 AS `userid`,
 1 AS `name`,
 1 AS `dob`,
 1 AS `mobile`,
 1 AS `email`,
 1 AS `usertype`,
 1 AS `loginstatus`,
 1 AS `regdate`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `userview`
--

/*!50001 DROP VIEW IF EXISTS `userview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `userview` AS select `userdetails`.`userid` AS `userid`,`userdetails`.`name` AS `name`,`userdetails`.`dob` AS `dob`,`userdetails`.`mobile` AS `mobile`,`userdetails`.`email` AS `email`,`users`.`usertype` AS `usertype`,`users`.`loginstatus` AS `loginstatus`,`userdetails`.`regdate` AS `regdate` from (`userdetails` join `users` on((`userdetails`.`userid` = `users`.`userid`))) where (`userdetails`.`userid` = `users`.`userid`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-05 17:11:09
