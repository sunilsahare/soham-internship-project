package com.banking.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.tomcat.dbcp.dbcp2.Jdbc41Bridge;

public class ManagerTask {
	
	public ManagerTask() {
		
	}
	
	//db connection 
	DBConnection db = new DBConnection();
	Connection con = db.getCon();
	
	//get All customer on manager page to manage them
	public ArrayList<UserDetailsBean> getAllCustomers(){
		ArrayList<UserDetailsBean> list = new ArrayList<UserDetailsBean>();
		UserDetailsBean user;
		
		//Jdbc objects
		PreparedStatement pst;
		ResultSet rs;
		try {
			pst=con.prepareStatement("select * from userview");
			rs = pst.executeQuery();
			while(rs.next()) {
				user = new UserDetailsBean(rs.getInt("userid"),rs.getString("name"),
						rs.getString("dob"),rs.getString("mobile"),rs.getString("email"),rs.getString("usertype"),
						rs.getString("loginstatus"),rs.getString("regdate"));
				//add to the  list
				list.add(user);
			}
			
			
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//method to give the permision to login------------------
	public boolean activateUser(int userid,String status) {
		PreparedStatement pst;
			
		try {
				
			pst = con.prepareStatement("update users set loginstatus=? where userid=?");
			pst.setString(1, status);
			pst.setInt(2, userid);
			int count = pst.executeUpdate();
			
			if(count>0) {
				return true;
			}
			else {
				return false;
			}
				
		}
		catch (Exception e) {

		}
		return false;
	}
	
	
	//get All Account holder info
	public ArrayList<AccountInfoBean> getAllAccounts(){
		ArrayList<AccountInfoBean> list = new ArrayList<AccountInfoBean>();
		AccountInfoBean account;
			
		//Jdbc objects
		PreparedStatement pst;
		ResultSet rs;
		try {
			pst=con.prepareStatement("select * from accounts");
			rs = pst.executeQuery();
			while(rs.next()) {
				account = new AccountInfoBean(rs.getInt("ano"),rs.getString("aname"),rs.getString("atype"),rs.getDouble("balance"),rs.getString("opendate"));
				//add to the  list
				list.add(account);
			}
				
				
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//Close the customer account using acc no
	public String closeAccount(int ano){
		//Jdbc objects
		PreparedStatement pst;
		try {
			pst=con.prepareStatement("delete from users where userid=?");
			pst.setInt(1, ano);
			int i = pst.executeUpdate();
			if(i>0) {
				return "sucess";
			}
			else {
				return "fail";
			}
		} 
		catch (Exception e) {
			return e.getMessage();
		}
		
	}
	
	
	
}
