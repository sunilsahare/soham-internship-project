package com.banking.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CustomerTask {
	
	public CustomerTask() {
		
	}
	//DbConnection 
	DBConnection db = new DBConnection();
	Connection con = db.getCon();
	
	
	//method which return customer account statement
	public ArrayList<AccountTxn> getAccountStatement(int ano){
		ArrayList<AccountTxn> list = new ArrayList<AccountTxn>();
		AccountTxn account;
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
			
		try {
				
			pst = con.prepareStatement("select * from acctransactions where ano=?");
			pst.setInt(1, ano);
			rs= pst.executeQuery();
			while(rs.next()) {
				account = new AccountTxn(rs.getInt("transno"),rs.getInt("ano"),rs.getString("transdt"),rs.getString("transtype"),rs.getDouble("amount"));
				list.add(account);
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
			
		return list;
	}

	
}
