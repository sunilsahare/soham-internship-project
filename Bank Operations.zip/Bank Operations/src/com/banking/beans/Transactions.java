package com.banking.beans;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class Transactions {
	
	public Transactions() {
		
	}
	
	//DbConnection 
	DBConnection db = new DBConnection();
	Connection con = db.getCon();
	
	//method which return Account information
	public ArrayList<AccountInfoBean> getAccountInfo(int ano){
		ArrayList<AccountInfoBean> list = new ArrayList<AccountInfoBean>();
		AccountInfoBean account;
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
		
		try {
			
			pst = con.prepareStatement("select * from accounts where ano=?");
			pst.setInt(1, ano);
			rs= pst.executeQuery();
			while(rs.next()) {
				account = new AccountInfoBean(rs.getInt("ano"),rs.getString("aname"),rs.getString("atype"),rs.getDouble("balance"),rs.getString("opendate"));
				list.add(account);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	//method which return Account information
	public ArrayList<AccountInfoBean> getAllAccountInfo(){
		ArrayList<AccountInfoBean> list = new ArrayList<AccountInfoBean>();
		AccountInfoBean account;
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
			
		try {
				
			pst = con.prepareStatement("select * from accounts");
			
			rs= pst.executeQuery();
			while(rs.next()) {
				account = new AccountInfoBean(rs.getInt("ano"),rs.getString("aname"),rs.getString("atype"),rs.getDouble("balance"),rs.getString("opendate"));
				list.add(account);
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	//transfer money to the customer
	public String depositMoney(int ano, double amount) {
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
		
		try {
			//ckeck the availability of account
			pst = con.prepareStatement("select * from accounts where ano=?");
			pst.setInt(1, ano);
			rs = pst.executeQuery();
			if(rs.next()) {
				//deposit the money
				pst = con.prepareCall("{call updatebal(?,?)}");
				pst.setInt(1, ano);
				pst.setDouble(2, amount);
				
				int i = pst.executeUpdate();
				if(i>0) {
					return "updated";
				}
				else {
					return "fail";
				}
				
			}
			else {
				return "acc-not-found";
			}
			
		} 
		catch (Exception e) {
			return e.getMessage();
		}
	}

	//transfer money to the customer
	public String withdrawMoney(int ano, double amount) {
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
			
		try {
			pst = con.prepareStatement("select * from accounts where ano=?");
			pst.setInt(1, ano);
			rs = pst.executeQuery();
			if(rs.next()) {
				
				//ckeck the availability of account balance
				pst = con.prepareStatement("select * from accounts where ano=? and balance>=?");
				pst.setInt(1, ano);
				pst.setDouble(2, amount);
				rs = pst.executeQuery();
				
				if(rs.next()) {
					//withdraw the money
					CallableStatement cst1;
					cst1 = con.prepareCall("{call withdrawbal(?,?)}");
					cst1.setInt(1, ano);
					cst1.setDouble(2, amount);
					int i = cst1.executeUpdate();
					
					if(i>0) {
						return "sucess";
					}
					else {
						return "fail";
					}
					
				}
				else {
					return "insufficient-bal";
				}
					
			}
			else {
				return "acc-not-found";
			}			
		} 
		catch (Exception e) {
			return e.getMessage();
		}
	}
	//method which return daily transactions report
	public ArrayList<AccountTxn> getTransactionReport(){
		ArrayList<AccountTxn> list = new ArrayList<AccountTxn>();
		AccountTxn account;
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
			
		try {
				
			pst = con.prepareStatement("select * from acctransactions where transdt=curdate()");
			rs= pst.executeQuery();
			while(rs.next()) {
				account = new AccountTxn(rs.getInt("transno"),rs.getInt("ano"),rs.getString("transdt"),rs.getString("transtype"),rs.getDouble("amount"));
				list.add(account);
			}
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
			
		return list;
	}

	//transfer money to the customer
	public String transferMoney(int srcno, int desno, double amount, String userRole,String trType) {
		//jdbc objects
		PreparedStatement pst;
		ResultSet rs;
				
		try {
			pst = con.prepareStatement("select * from accounts where ano=?");
			pst.setInt(1, srcno);
			rs = pst.executeQuery();
			if(rs.next()) {
				
				//check the availability of beneficiary account
				pst = con.prepareStatement("select * from accounts where ano=?");
				pst.setInt(1, desno);
				rs = pst.executeQuery();
				if(rs.next()) {
					
					//ckeck the availability of source account balance
					pst = con.prepareStatement("select * from accounts where ano=? and balance>=?");
					pst.setInt(1, srcno);
					pst.setDouble(2, amount);
					rs = pst.executeQuery();
					if(rs.next()) {
						
						//check user role and transfer limit
						if(userRole.equals("manager")){
							//unlimited transfer
							//call the procedure which transfer the money
							CallableStatement cst1;
							cst1 = con.prepareCall("{call transferMoney(?,?,?,?)}");
							cst1.setInt(1, srcno);
							cst1.setInt(2, desno);
							cst1.setDouble(3, amount);
							cst1.setString(4, trType);
							int i = cst1.executeUpdate();
							if(i>0) {
								return "sucess";
							}
							else {
								return "fail";
							}
							
							
						}
						else if (userRole.equals("cashier")){
							if(amount<=20000){
								//call the procedure which transfer the money
								CallableStatement cst1;
								cst1 = con.prepareCall("{call transferMoney(?,?,?,?)}");
								cst1.setInt(1, srcno);
								cst1.setInt(2, desno);
								cst1.setDouble(3, amount);
								cst1.setString(4, trType);
								int i = cst1.executeUpdate();
								if(i>0) {
									return "sucess";
								}
								else {
									return "fail";
								}
								
							}
							else{
								return "You can not transfer more than 20000";
							}
						}
						else if (userRole.equals("customer")){
							if(amount<=5000){
								
								//call the procedure which withdra the money
								CallableStatement cst1;
								cst1 = con.prepareCall("{call transferMoney(?,?,?,?)}");
								cst1.setInt(1, srcno);
								cst1.setInt(2, desno);
								cst1.setDouble(3, amount);
								cst1.setString(4, trType);
								int i = cst1.executeUpdate();
								if(i>0) {
									return "sucess";
								}
								else {
									return "fail";
								}
								
							}
							else{
								return "You can not transfer more than 5000";
							}
						}
					}
					else {
						return "insufficient-bal";
					}
				}
				else {
					return "des-acc-not-found";
				}
						
			}
			else {
				return "src-acc-not-found";
			}			
		} 
		catch (Exception e) {
			return e.getMessage();
		}
		return "fail";
	}

	
	
	
	
	
	
}//class
