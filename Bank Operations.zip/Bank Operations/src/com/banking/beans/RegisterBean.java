package com.banking.beans;

import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;





public class RegisterBean {

    public RegisterBean() {
    	
    }
    

	DBConnection db =new DBConnection();
	Connection con = db.getCon();
    
    //chech user authenticity
    public String validateUser(int userid,String password){
        try {
        	PreparedStatement pst = con.prepareStatement("select * from users where userid=? and password=? and loginstatus='active'");
            pst.setInt(1, userid);
            pst.setString(2, password);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
            	if(userid==rs.getInt("userid") && password.equals(rs.getString("password"))) {
            		return rs.getString("usertype");
            	}
            	else {
            		return "not_found";
            	}
            	
            }
            else{
                return "not_found";
            }
            
        } 
        catch (Exception e) {
			e.printStackTrace();
		}
    
        return "not_found"; 
    }
    
   
  //-------add customer----------------------------
    public String addnewAccount(int userid, String password ,
    		String name, String dob,String mobile,String email,String secque, String ans,String city,double balance){
    	PreparedStatement pst;
        try {
        	DBConnection db =new DBConnection();
        	Connection con = db.getCon();
        	//check user exist or not
        	pst=con.prepareStatement("select * from userdetails where name=? and email=?");
        	pst.setString(1, name);
        	pst.setString(2, email);
        	ResultSet rs = pst.executeQuery();
        	
        	//check here user is exists or not
        	if(rs.next()) {
        		return "user-exists";
        	}
        	else {	
        		CallableStatement cst;
        		cst = con.prepareCall("{call register(?,?,?,?,?,?,?,?,?,?)}");
        		cst.setInt(1, userid);
        		cst.setString(2, name);
        		cst.setString(3, password);
        		cst.setString(4, dob);
        		cst.setString(5, mobile);
        		cst.setString(6, email);
        		cst.setString(7, city);
        		cst.setString(8, secque);
        		cst.setString(9, ans);
        		cst.setDouble(10, balance);
        		
        		int i = cst.executeUpdate();
        		if(i>0) {
        			return "sucess";
        		}
        		else {
        			return "fail";
        		}
        	}
        	
        }
        catch (Exception e) {
			return "username-exists";
		} 
        
    }
    
  
    
    
    
    //------------chenge pass ------------------------------
    public String changePass(int userid,String password,String npass, String cpass){
        PreparedStatement pst;
    	try {
        	if(npass.equals(cpass)) {
        		pst=con.prepareStatement("update users set password=? where userid=? and password=?");
    			pst.setString(1, npass);
    			pst.setInt(2, userid);
    			pst.setString(3, password);
    			int i = pst.executeUpdate();
    			if(i>0) {
    				return "sucess";
    			}
    			else {
    				return "fail";
    			}
        	}
        	else {
        		return "pass-not-match";
        	}
			        
        } catch (Exception ex) {
            return ex.getMessage();
        }
    }
    
    
    //-------------get Uer Name---------------------------------
    public String getName(int userid){
    	DBConnection db =new DBConnection();
    	Connection con = db.getCon();
    	PreparedStatement pst;
		try {
			pst = con.prepareStatement("select * from users where userid=?");
			pst.setInt(1, userid);
	        ResultSet rs = pst.executeQuery();
	        if(rs.next()) {
	        	return rs.getString("name");
	        }
	        
		} catch (SQLException e) {
			e.printStackTrace();
		}
        
    	return "";
    }

  //-------------get Account number---------------------------------
    public int getAccountNo(String operator){
    	DBConnection db =new DBConnection();
    	Connection con = db.getCon();
    	PreparedStatement pst;
		try {
			pst = con.prepareStatement("select * from accounts where aname=?");
			pst.setString(1, operator);
	        ResultSet rs = pst.executeQuery();
	        if(rs.next()) {
	        	return rs.getInt("ano");
	        }
	        
		} catch (SQLException e) {
			e.printStackTrace();
		}
        
    	return 0;
    }

    
    
    
    
    
}//class
