package com.banking.beans;

public class UserDetailsBean {
	
	//properties
	private int userid;
	private String name;
	private String dob;
	private String mobile;
	private String email;
	private String userType;
	private String loginStatus;
	private String regDate;
	
	public UserDetailsBean() {
		super();
	}

	public UserDetailsBean(int userid, String name, String dob, String mobile, String email,
			String userType, String loginStatus, String regDate) {
		super();
		this.userid = userid;
		this.name = name;
		this.dob = dob;
		this.mobile = mobile;
		this.email = email;
		this.userType = userType;
		this.loginStatus = loginStatus;
		this.regDate = regDate;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setFirstName(String name) {
		this.name = name;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	
	
	
}
