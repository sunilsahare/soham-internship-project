package com.banking.beans;

public class AccountInfoBean {
	//properties
	private int accNo;
	private String Name;
	private String accType;
	private double balance;
	private String openDate;
	
	public AccountInfoBean (){
		
	}

	public AccountInfoBean(int accNo, String name, String accType, double balance, String openDate) {
		super();
		this.accNo = accNo;
		
		Name = name;
		this.accType = accType;
		this.balance = balance;
		this.openDate = openDate;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	
	
}
