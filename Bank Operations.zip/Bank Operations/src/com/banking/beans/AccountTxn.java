package com.banking.beans;

public class AccountTxn {
	//properties
	private int tranNo;
	private int ano;
	private String tranDate;
	private String transType;
	private double amount;
	
	public AccountTxn() {
		
	}

	public AccountTxn(int tranNo, int ano, String tranDate, String transType, double amount) {
		super();
		this.tranNo = tranNo;
		this.ano = ano;
		this.tranDate = tranDate;
		this.transType = transType;
		this.amount = amount;
	}

	public int getTranNo() {
		return tranNo;
	}

	public void setTranNo(int tranNo) {
		this.tranNo = tranNo;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getTranDate() {
		return tranDate;
	}

	public void setTranDate(String tranDate) {
		this.tranDate = tranDate;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
}
