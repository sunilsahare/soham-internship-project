package com.banking.beans;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Test {

	
	public static void main(String[] args) {
	
		//db connection
		DBConnection dbConnection = new DBConnection();
		Connection con = dbConnection.getCon();

		PreparedStatement pst;
		ResultSet rs;
			
		int ano = 20303;
		double amount=3000;
		try {
			pst = con.prepareStatement("select * from accounts where ano=?");
			pst.setInt(1, ano);
			rs = pst.executeQuery();
			if(rs.next()) {
				
				//ckeck the availability of account balance
				pst = con.prepareStatement("select * from accounts where ano=? and balance>=?");
				pst.setInt(1, ano);
				pst.setDouble(2, amount);
				rs = pst.executeQuery();
				
				if(rs.next()) {
					//withdraw the money
					CallableStatement cst1;
					cst1 = con.prepareCall("{call withdrawbal(?,?)}");
					cst1.setInt(1, ano);
					cst1.setDouble(2, amount);
					int i = cst1.executeUpdate();
					
					if(i>0) {
						System.out.println("Sucess");
						//return "sucess";
					}
					else {
						System.out.println("fail");
						//return "fail";
					}
					
				}
				else {
					System.out.println("Insufficient Balance");
					//return "insufficient-bal";
				}
					
			}
			else {
				System.out.println("acc-not-found");
				//return "acc-not-found";
			}			
		} 
		catch (Exception e) {
			e.printStackTrace();
			//return e.getMessage();
		}
	
	
		


	}

}
